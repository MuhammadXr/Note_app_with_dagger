package uz.gita.noteapp_by_xr.domain.usecase

interface DeleteAllNoteUseCase {

    suspend fun deleteAllNotes()

}