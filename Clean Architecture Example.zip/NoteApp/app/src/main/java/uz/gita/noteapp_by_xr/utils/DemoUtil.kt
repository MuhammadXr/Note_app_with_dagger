package uz.gita.noteapp_by_xr.utils

class DemoUtil {

}
