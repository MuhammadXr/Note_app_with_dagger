package uz.gita.noteapp_by_xr.presenter

import androidx.lifecycle.LiveData

interface SplashViewModel {

    val openMainScreenLiveData: LiveData<Unit>

}