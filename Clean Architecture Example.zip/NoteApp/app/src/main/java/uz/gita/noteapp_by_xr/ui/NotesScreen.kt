package uz.gita.noteapp_by_xr.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import uz.gita.noteapp_by_xr.R
import uz.gita.noteapp_by_xr.ui.list_adapter.NotesAdapter


class NotesScreen : Fragment(R.layout.fragment_notes_screen) {



    //private val viewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


    }
}